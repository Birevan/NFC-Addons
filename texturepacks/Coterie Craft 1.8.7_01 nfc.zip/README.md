# Coterie Craft by Cpt_Corn for NFC

Supports Panorama, Water Biome Colors (optional), Bottom Chest Texture and [JalC](../../mods/Just%20a%20little%20Cyrillic.zip) addons.

**Download versions:**

* [NFC 1.8.7](../Coterie%20Craft%201.8.7_01%20nfc.zip)

[![Coterie Craft](https://i.imgur.com/nggoe4M.png)](https://newfrontiercraft.net/thread/131/coterie-craft-cpt-corn-nfc "Click to see more screenshots")

Originally by Cpt_Corn:

* [Original resource packs website](https://coteriecraft.net/downloads/)

* [Original resource packs Planet Minecraft](https://www.planetminecraft.com/texture-pack/16x-beta-17_01-coterie-craft-v16-regular-upd-6302011/)

* [Original resource packs Minecraft Forums](https://www.minecraftforum.net/forums/mapping-and-modding-java-edition/resource-packs/1223548-32x-16x-coterie-craft-default-revamped)
